<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;


class WelcomeController extends AbstractController
{
    /**
     * @Route("/welcome", name="welcome")
     */
    public function index()
    {
        return $this->render('welcome/index.html.twig', [
            'controller_name' => 'WelcomeController',
        ]);
    }

    /**
     * @Route("/hello_page", name="hello_page")
     */
    public function hello(Request $request){
    	return $this->render('hello_page.html.twig',
    		[
    			'some_variable' => 'anything you like',
    			'another_variable' => false,
    			'name' => $request->query->get('name'),
    		]
    	);
    }
}
 